<?php
    define("HOST", '127.0.0.1');
    define("USER", 'root');
    define("PASS", '');
    define("BASE", 'login');

    $con = new mysqli(HOST, USER, PASS, BASE);

    if($con->connect_errno){
        die('No se pudo conectar a la base de datos: ' . $con->connect_error);
    }

    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
?>