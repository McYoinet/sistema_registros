<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="estilos/estilos.css">
        <title>Iniciar sesión</title>
    </head>

    <body>
        <?php
            if(!(isset($_SESSION))){
                session_start();
            }

            if(!(isset($_SESSION['estado']))){
                $_SESSION['estado'] = false;
            }

            if(!(isset($_SESSION['nombre']))){
                $_SESSION['nombre'] = "(error)";
            }

            if(!(isset($_SESSION['mensaje']))){
                $_SESSION['mensaje'] = null;
            }
        ?>

        <h1>Proyecto: Registro de usuarios.</h1>
            <?php
                if(!($_SESSION['estado'])){
                    require("form_login.php");
                    require("validar_login.php");

                    $validar = new validar_datos();

                    if(isset($_POST['login'])){
                        $usuario = $_POST['usuario'];
                        $clave = hash('sha3-512', $_POST['clave']);
                    
                        if($validar->validarNombre($usuario)){
                            if($validar->validarClave($clave)){
                                $_SESSION['estado'] = true;
                                $_SESSION['nombre'] = $usuario;
                                header("Location: salir.php");
                                exit();
                            }else{
                                $_SESSION['estado'] = false;
                                $_SESSION['mensaje'] = "Contraseña incorrecta.";
                                header('Location: index.php');
                                exit();
                            }
                        }else{
                            $_SESSION['estado'] = false;
                            $_SESSION['mensaje'] = "Ese nombre de usuario no está registrado.";
                            header('Location: index.php');
                            exit();
                        }
                    }
                }else{
                    include("salir.php");
                }
            ?>

        <div id="pie">
            <p>Creado por Christian Mardueño.</p>
        </div>
    </body>
</html>