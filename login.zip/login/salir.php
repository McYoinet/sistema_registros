<div class="contenedor">
    <h2>¡Bienvenido, <?php echo $_SESSION['nombre']?></h1>

    <button class="boton" onclick="salir()">Salir</button>
    <script>
        function salir(){
            "<?php session_reset();?>"
        }
    </script>
</div>